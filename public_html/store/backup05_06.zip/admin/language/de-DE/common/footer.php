<?php
/**
 * @version		$Id: footer.php 3750 2014-09-28 16:22:31Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */
// Text
$_['text_footer'] = '<a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.<br />Dt. Version von <a href="http://osworx.net" target="_blank">OSWorX</a>';
$_['text_version']= 'Version %s';